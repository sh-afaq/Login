﻿using System.ComponentModel.DataAnnotations;

namespace Login.Models
{
    public class Login_model
    {
        [Required(ErrorMessage = "UserName is required")]
        public string UserName { get; set; }
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
