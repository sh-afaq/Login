﻿using Microsoft.AspNetCore.Mvc;
using Login.Models;
using System.Data.SqlClient;
namespace Login.Controllers
{
    public class LoginController : Controller
    {
        
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }
        void ConnectionString()
        {

        }
        public IActionResult Verify(Login_model login)
        {
            return View();
        }
    }
}
